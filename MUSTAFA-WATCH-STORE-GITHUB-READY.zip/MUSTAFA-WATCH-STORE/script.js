// MUSTAFA WATCH STORE
// Product buttons already open WhatsApp with the product name and price.
// To change your WhatsApp number, replace 923452745122 in index.html.
document.addEventListener("DOMContentLoaded", () => {
  console.log("MUSTAFA WATCH STORE is ready.");
});
