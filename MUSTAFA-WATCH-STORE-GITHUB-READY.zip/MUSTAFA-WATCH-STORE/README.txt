MUSTAFA WATCH STORE
GitHub Pages ready.

1. Upload ALL files and folders to your GitHub repository.
2. Make sure index.html is in the repository root.
3. Settings > Pages > Deploy from a branch > main > /(root) > Save.
4. Your GitHub Pages site will appear after deployment.

WhatsApp number currently set to: 0345 2745122
To change it, replace 923452745122 in index.html.
To add real product photos, replace images/watch1.svg, watch2.svg, watch3.svg
with your own image files and update the image filenames in index.html.
